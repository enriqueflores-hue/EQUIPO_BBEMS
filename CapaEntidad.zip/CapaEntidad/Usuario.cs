﻿namespace CapaEntidad
{
    public class Usuario
    {
        public string Nombre { get; set; }
        public string Apellidos { get; set; }
        public string Direccion { get; set; }
        public string Email { get; set; }
        public string Contrasena { get; set; }
        public string Peso { get; set; }
        public string Edad { get; set; }
        public string Rol { get; set; }  // "Usuario" o "Administrador"
    }
}

