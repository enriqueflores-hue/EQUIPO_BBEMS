﻿using CapaDatos;
using CapaEntidad;
using System.Collections.Generic;
using System.ComponentModel;

namespace CapaNegocio
{
    public class ContactoBLL
    {
        private ContactoDAL dal = new ContactoDAL();

        public BindingList<Contacto> Listar()
        {
            return dal.Listar(); // Ya devuelve BindingList<Contacto>
        }



        public bool Insertar(Contacto c)
        {
            return dal.Insertar(c);
        }

        public bool Modificar(Contacto c)
        {
            return dal.Modificar(c);
        }

        public bool Eliminar(int id)
        {
            return dal.Eliminar(id);
        }
    }
}
