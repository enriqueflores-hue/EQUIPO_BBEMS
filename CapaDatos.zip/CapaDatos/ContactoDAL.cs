﻿using CapaEntidad;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;

namespace CapaDatos
{
    public class ContactoDAL
    {
        
        private string connectionString =
            @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=dispositivo_epilepsia;Integrated Security=True;";

     
        public BindingList<Contacto> Listar()
        {
            BindingList<Contacto> lista = new BindingList<Contacto>();

            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                string query = "SELECT IdContacto, Nombre, Apellidos, Direccion, Email, Telefono FROM Contacto";
                SqlCommand cmd = new SqlCommand(query, cn);
                cn.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    lista.Add(new Contacto
                    {
                        idContacto = Convert.ToInt32(dr["IdContacto"]),
                        Nombre = dr["Nombre"].ToString(),
                        Apellidos = dr["Apellidos"].ToString(),
                        Direccion = dr["Direccion"].ToString(),
                        Email = dr["Email"].ToString(),
                        Telefono = dr["Telefono"].ToString()
                    });
                }
            }
            return lista;
        }

        
        public bool Insertar(Contacto c)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                string query = @"INSERT INTO Contacto 
                                 (Nombre, Apellidos, Direccion, Email, Telefono) 
                                 VALUES (@Nombre, @Apellidos, @Direccion, @Email, @Telefono)";

                SqlCommand cmd = new SqlCommand(query, cn);

                cmd.Parameters.AddWithValue("@Nombre", c.Nombre);
                cmd.Parameters.AddWithValue("@Apellidos", c.Apellidos);
                cmd.Parameters.AddWithValue("@Direccion", c.Direccion);
                cmd.Parameters.AddWithValue("@Email", c.Email);
                cmd.Parameters.AddWithValue("@Telefono", c.Telefono);

                cn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        
        public bool Modificar(Contacto contacto)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                string query = @"UPDATE Contacto 
                                 SET Nombre = @Nombre, Apellidos = @Apellidos, Direccion = @Direccion, 
                                     Email = @Email, Telefono = @Telefono 
                                 WHERE IdContacto = @IdContacto";

                SqlCommand cmd = new SqlCommand(query, cn);

                cmd.Parameters.AddWithValue("@Nombre", contacto.Nombre);
                cmd.Parameters.AddWithValue("@Apellidos", contacto.Apellidos);
                cmd.Parameters.AddWithValue("@Direccion", contacto.Direccion);
                cmd.Parameters.AddWithValue("@Email", contacto.Email);
                cmd.Parameters.AddWithValue("@Telefono", contacto.Telefono);
                cmd.Parameters.AddWithValue("@IdContacto", contacto.idContacto);

                cn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

       
        public bool Eliminar(int id)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Contacto WHERE IdContacto = @IdContacto";
                SqlCommand cmd = new SqlCommand(query, cn);
                cmd.Parameters.AddWithValue("@IdContacto", id);

                cn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }
    }
}
